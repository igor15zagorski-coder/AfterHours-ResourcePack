AFTERHOURS SMP — VISUAL PACK v2
Minecraft Java Edition 1.21.11
Resource Pack version: 75.0

KIERUNEK:
Dark fantasy / purple-black / moon / gothic / mystical.

CO ZMIENIA v2:
- ponad 100 własnych / przerobionych tekstur
- kamień, deepslate, blackstone, nether/end i bloki budowlane
- większość podstawowych desek, pni i liści
- wszystkie główne rudy + warianty deepslate
- dużo bloków świetlnych i sculk
- narzędzia wszystkich tierów
- zbroje jako ikony itemów
- miecze, kilofy, siekiery, łopaty, motyki
- Mace, Spear, Trident
- Elytra, Shield, Totem
- Nether Star, Eye of Ender, Ender Pearl
- Golden Apple / Enchanted Golden Apple
- Experience Bottle
- Bow + animacje naciągania
- fioletowy księżyc i fazy
- własne słońce
- ciemny End sky
- fioletowe chmury
- fioletowy enchant glint

FUTURE CUSTOM ASSETS:
assets/afterhours/textures/item/
- dragon_key.png
- lunar_token.png
- dragonfang_sword.png
- moonblade.png
- void_pickaxe.png

Te pliki są przygotowane pod przyszły system custom itemów.
Same nie podmieniają vanilla itemów bez mapowania/modelu/pluginu.

WAŻNE:
Vanilla resource pack nie może zrobić pełnego shaderowego nieba,
mgły wolumetrycznej ani oświetlenia jak na grafikach promocyjnych.
To wymaga shadera lub moda klienta.
Ten pack robi maksymalnie mocny styl, który da się dostarczyć
zwykłym server resource packiem bez wymagania modów.

AFTERHOURS SMP
afterhours.cldly.gg
discord.gg/YV38faV4F
