AFTERHOURS SMP — VISUAL PACK v1

Minecraft Java Edition: 1.21.11
Resource pack version: 75.0

Ta wersja zmienia:
- księżyc i jego fazy na fioletowy styl AfterHours
- wygląd nieba w Endzie na ciemny fiolet / gwiazdy
- Totem of Undying
- Nether Star
- Eye of Ender
- ikonę paczki

WAŻNE:
Vanilla resource pack nie potrafi w pełni podmienić proceduralnego
nieba i gwiazd Overworldu na własną mgławicę bez dodatkowego wsparcia
klienta (np. rozwiązania typu custom sky/shader/mod).

Paczka nie daje żadnej przewagi w grze.
